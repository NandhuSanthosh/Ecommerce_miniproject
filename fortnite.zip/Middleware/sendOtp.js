// const twilio = require('twilio');


// const accountSid = process.env.TWILIO_ACCOUNT_SID;
// const authToken = process.env.TWILIO_AUTH_TOKEN ;

// const client = twilio(accountSid, authToken);

// const fromPhoneNumber = process.env.TWILIO_PHONE_NUMBER;


// function sendOtp(message, toPhoneNumber = '+916238973581'){
//     return client.messages
//       .create({
//         body: message,
//         from: fromPhoneNumber,
//         to: toPhoneNumber
//       })
// }

// module.exports = sendOtp;
